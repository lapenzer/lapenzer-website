# UZUSKE 1.0

UZUSKE is a local route and sequence prediction model from Lapenzer. This evaluation build ranks loop-free candidate routes through a directed network using historical transitions, edge priors, and recent observations.

## Requirements

- Python 3.10 or newer
- No third-party Python packages
- No internet connection required after download

## Run on Windows

Double-click `run.bat`, or open PowerShell in this folder and run:

```powershell
python uzuske.py run examples\network.json
```

## Run on macOS or Linux

```bash
python3 uzuske.py run examples/network.json
```

## JSON output

```bash
python3 uzuske.py run examples/network.json --json
```

## Input format

The JSON file contains `start`, `destination`, `observations`, `edges`, and `historical_traces`.

## Model behaviour

UZUSKE 1.0 uses deterministic loop-free beam search. Candidate routes are scored using smoothed historical transition probabilities, structural edge priors, and a decayed recency bonus for recently observed transitions. The top routes are normalized into a probability distribution.

This evaluation build is functional local software. It does not claim validated production performance on external operational datasets.

## Local HTTP API

Start the included local API:

```bash
python uzuske.py serve --port 8080
```

Health check:

```bash
curl http://127.0.0.1:8080/health
```

Send a prediction request by POSTing the same JSON schema to `http://127.0.0.1:8080/predict`.
