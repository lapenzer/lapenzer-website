@echo off
python uzuske.py run examples\network.json
pause
