#!/usr/bin/env sh
python3 uzuske.py run examples/network.json
